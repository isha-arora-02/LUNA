import torch
from torch.utils.data import DataLoader, Dataset
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import WeightedRandomSampler
from tqdm import tqdm
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from load_monet import image_encoder, transcriptomics_encoder, joint_model, get_img_embeddings, compute_loss, predict, get_monet_model, precompute_img_embeddings


class DatasetPrep(Dataset):
    def __init__(self, img_embeddings, gene_expression, labels):
        self.img_embeddings = img_embeddings
        self.gene_expression = gene_expression
        self.labels = labels
    
    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        return self.img_embeddings[idx], self.gene_expression[idx], self.labels[idx]
    
#CP defined more args
class TrainValLUNA:
    def __init__(self, num_classes=7, img_dim=1024, omics_dim=663,
             embed_dim=512, lr=1e-4, weight_decay=0.01,
             dropout=0.3, lambda_val=0.7, supcon_temp=0.1):
        """
        Parameters:
        num_classes: number of predicted classes
        img_dim: input image dimension
        omics_dim: input omics dimension
        out_dim: output dimension for encoder models
        embed_dim: embedding dimension in mid of training
        device: device to run on
        lr: learning rate
        """
        #CP adds the init of these 2 args
        self.lambda_val = lambda_val
        self.supcon_temp = supcon_temp

        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.num_classes = num_classes
        
        self.img_encoder = image_encoder(
            first_layer_dim=img_dim, 
            out_dim=embed_dim
        ).to(self.device)
        
        self.omics_encoder = transcriptomics_encoder(
            num_genes=omics_dim, 
            out_dim=embed_dim
        ).to(self.device)
        
        #CP added dropout
        self.joint_model = joint_model(
            in_dim=embed_dim, 
            num_classes=num_classes, 
            dropout=dropout).to(self.device)
        
        self.monet_model, self.monet_processor = get_monet_model()
        
        self.monet_model.to(self.device)
        
        trainable_params = (
            list(self.img_encoder.parameters()) +
            list(self.omics_encoder.parameters()) +
            list(self.joint_model.parameters())
        )
        # CP added wd arg
        self.optimizer = AdamW(trainable_params, lr=lr, weight_decay=weight_decay)
        self.scheduler = None
        
        self.history = {
            'train_loss': [],
            'train_acc': [],
            'val_loss': [],
            'val_acc': [],
        }

        self.best_val_loss = float('inf')

    def precompute_monet_embeddings(self, images, batch_size):
        return precompute_img_embeddings(images, self.monet_model, self.monet_processor, self.device, batch_size)

    def train_model(self, train_loader, val_loader, num_epochs):
        """
        Train the model over multiple epochs and print statistics at each iteration.

        Parameters:
        train_loader: dataloader function for train dataset
        val_loader: dataloader function for validation dataset
        num_epochs: number of epochs of training
       
        Returns:
        img_enc: encoder model for images
        omics_enc: encoder model for omics
        joint: joint model
        """
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=num_epochs)
        
        for epoch in range(num_epochs):
            # Training phase
            self.img_encoder.train()
            self.omics_encoder.train()
            self.joint_model.train()
            
            train_loss = 0.0
            train_correct = 0
            train_total = 0
            
            for img_embeddings, gene_expr, y_val in tqdm(train_loader, desc=f"Epoch {epoch}"):
                # get precomputed img embeddings
                img_embeddings = img_embeddings.to(self.device)

                # to device for expr and y labels
                gene_expr = gene_expr.to(self.device)
                y_val = y_val.to(self.device)
                
                # forward pass through models
                img_embed = self.img_encoder(img_embeddings)
                omics_embed = self.omics_encoder(gene_expr)
                final_pred = self.joint_model(img_embed, omics_embed)
                
                # calc loss # CP adds lambda/supcon
                loss = compute_loss(final_pred, img_embed, omics_embed, y_val,
                    lambda_val=self.lambda_val, supcon_temp=self.supcon_temp)
                
                # backward pass through model
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                
                # track eval/accuracy %/loss values
                train_loss += loss.item()
                _, predicted_class = torch.max(final_pred.squeeze(1), 1)
                train_total += y_val.size(0)
                train_correct += (predicted_class == y_val).sum().item()
            
            # run validation
            val_loss, val_acc = self.validate(val_loader)            
            
            # update lr
            self.scheduler.step()
            
            # print stats so far
            train_loss /= len(train_loader)
            train_acc = 100 * train_correct / train_total
            print(f"Epoch {epoch}: Train Loss={train_loss:.4f}, Train Acc={train_acc:.2f}%, "
                f"Val Loss={val_loss:.4f}, Val Acc={val_acc:.2f}%")
            
            self.history['train_loss'].append(train_loss) 
            self.history['train_acc'].append(train_acc)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)

            with open('train_val_acc_history.pkl', 'wb') as f:
                pickle.dump(self.history, f)

                        
            # saving best model
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                torch.save({
                    'img_encoder': self.img_encoder.state_dict(),
                    'omics_encoder': self.omics_encoder.state_dict(),
                    'joint_model': self.joint_model.state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'scheduler': self.scheduler.state_dict(),
                    'epoch': epoch,
                    'val_loss': val_loss
                }, 'best_model.pt')
                print(f"Saved the best model so far with val_loss={val_loss:.4f}")


            if (epoch + 1) % 5 == 0:
                torch.save({
                    'img_encoder': self.img_encoder.state_dict(),
                    'omics_encoder': self.omics_encoder.state_dict(),
                    'joint_model': self.joint_model.state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'scheduler': self.scheduler.state_dict(),
                    'epoch': epoch,
                    'history': self.history
                }, f'checkpoint_epoch_{epoch}.pt')
        
        return self.img_encoder, self.omics_encoder, self.joint_model


    def validate(self, val_loader):
        """
        Runs analyses for validation.

        Parameters:
        val_loader: dataloader function for validation dataset

        Returns:
        val_loss: validation loss
        val_acc: validation accuracy
        """

        self.img_encoder.eval()
        self.omics_encoder.eval()
        self.joint_model.eval()
        
        val_loss = 0.0
        correct = 0
        total = 0
        
        # don't update weights
        with torch.no_grad():
            for img_embeddings, gene_expr, y_val in val_loader:
                # transfer data to correct device
                gene_expr = gene_expr.to(self.device)
                y_val = y_val.to(self.device)
                
                # get embeddings and fwd pass through model for inference
                img_embeddings = img_embeddings.to(self.device)
                img_embed = self.img_encoder(img_embeddings)
                omics_embed = self.omics_encoder(gene_expr)
                final_pred = self.joint_model(img_embed, omics_embed)
                
                # calculate loss # CP does same here
                loss = compute_loss(final_pred, img_embed, omics_embed, y_val,
                    lambda_val=self.lambda_val, supcon_temp=self.supcon_temp)
                val_loss += loss.item()
                
                # track accuracy metrics
                _, predicted = torch.max(final_pred.squeeze(1), 1)
                total += y_val.size(0)
                correct += (predicted == y_val).sum().item()
        
        # calc total loss and accuracy % for this model
        val_loss /= len(val_loader)
        val_acc = 100 * correct / total
        
        return val_loss, val_acc


if __name__ == "__main__":
    print("Choosing the best parameters from the hyperparameter optimization results...")
    SUMMARY_CSV = "out_data/run_summary.csv"

    HP_COLS = ["embed_dim","lr","weight_decay","dropout","lambda_val","supcon_temp","batch_size"]

    summary = pd.read_csv(SUMMARY_CSV)

    best_row = summary.sort_values("best_val_acc", ascending=False).iloc[0]

    BEST_CFG = {k: best_row[k] for k in HP_COLS}

    BEST_CFG["embed_dim"]   = int(BEST_CFG["embed_dim"])
    BEST_CFG["batch_size"]  = int(BEST_CFG["batch_size"])
    BEST_CFG["dropout"]     = float(BEST_CFG["dropout"])
    BEST_CFG["lr"]          = float(BEST_CFG["lr"])
    BEST_CFG["weight_decay"]= float(BEST_CFG["weight_decay"])
    BEST_CFG["lambda_val"]  = float(BEST_CFG["lambda_val"])
    BEST_CFG["supcon_temp"] = float(BEST_CFG["supcon_temp"])
    print("Best config:", BEST_CFG)

    # load the gene expression datasets - ensure they are in torch
    gene_expr_dat = pd.read_csv("gene_expr_data/final_expr.csv", index_col=0)
    gene_expr_dat_tensor = torch.from_numpy(gene_expr_dat.values).float()

    gene_expr_pheno = pd.read_csv("gene_expr_data/final_pheno.csv", index_col=0)
    gene_expr_pheno["disease_status_ind"] = pd.Categorical(gene_expr_pheno['disease_status']).codes
    gene_expr_labels_tensor = torch.tensor(gene_expr_pheno['disease_status_ind'].values, dtype=torch.long)

    # print statments to check
    print(f"Gene expression shape: {gene_expr_dat_tensor.shape}")
    print(f"Number of samples: {len(gene_expr_labels_tensor)}")
    print(f"Class distribution: {torch.bincount(gene_expr_labels_tensor)}")
    print(f"Classes: {pd.Categorical(gene_expr_pheno['disease_status']).categories.tolist()}")

    with open('/home/provido/provido/luna_final/LUNA-main/image_data/final_images_sorted.pkl', 'rb') as f:
        images_dat_lst = pickle.load(f)

    label_mapping = {
        'classes': pd.Categorical(gene_expr_pheno['disease_status']).categories.tolist(),
        'label_to_idx': dict(enumerate(pd.Categorical(gene_expr_pheno['disease_status']).categories))
        }
    with open('label_mapping.pkl', 'wb') as f:
        pickle.dump(label_mapping, f)

    # ensure labels were correctly generated 
    #assert len(images_labels_lst_tensor) == len(gene_expr_labels_tensor), "Label length mismatch"
    #assert torch.equal(images_labels_lst_tensor, gene_expr_labels_tensor), "Label value mismatch"

    # get train test splits
    train_images, val_images, \
    train_gene_expr, val_gene_expr, \
    train_images_labels, val_images_labels = train_test_split(
        images_dat_lst,
        gene_expr_dat_tensor,
        gene_expr_labels_tensor,
        test_size=0.25,
        stratify=gene_expr_labels_tensor.numpy(),
        random_state=42
    )

    # initialize training class instance
    #CP adds this, initializing with best params
    train_instance = TrainValLUNA(
        num_classes=7, img_dim=1024, omics_dim=663,
        embed_dim=BEST_CFG["embed_dim"],
        lr=BEST_CFG["lr"],
        weight_decay=BEST_CFG["weight_decay"],
        dropout=BEST_CFG["dropout"],
        lambda_val=BEST_CFG["lambda_val"],
        supcon_temp=BEST_CFG["supcon_temp"],
    )
    print("Pre-computing train embeddings...")
    train_img_embs = train_instance.precompute_monet_embeddings(train_images, batch_size=BEST_CFG["batch_size"])
    #torch.save(train_img_embs, "train_precomputed_monet_embeddings.pt")

    print("Pre-computing val embeddings...")
    val_img_embs   = train_instance.precompute_monet_embeddings(val_images, batch_size=BEST_CFG["batch_size"])
    #torch.save(val_img_embs, "val_precomputed_monet_embeddings.pt")

    # ensure embeddings are the right shape
    assert train_img_embs.shape[1] == 1024, f"Expected 768 dims, got {train_img_embs.shape[1]}"
    assert train_gene_expr.shape[1] == 663, f"Expected 663 dims, got {train_gene_expr.shape[1]}"

    # prepare datasets
    train_dataset = DatasetPrep(train_img_embs, train_gene_expr, train_images_labels)
    val_dataset = DatasetPrep(val_img_embs, val_gene_expr, val_images_labels)
    
    # create dataloaders
    train_loader = DataLoader(train_dataset, batch_size=BEST_CFG["batch_size"], shuffle=True, num_workers=4, pin_memory=True, prefetch_factor=1)
    val_loader = DataLoader(val_dataset, batch_size=BEST_CFG["batch_size"], shuffle=False, num_workers=4, pin_memory=True, prefetch_factor=1)
    
    # run training and eval
    img_enc, omics_enc, joint = train_instance.train_model(
        train_loader, 
        val_loader, 
        num_epochs=30
    )